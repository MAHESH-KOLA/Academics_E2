#include<bits/stdc++.h>
using namespace std;
struct node{
  int data;
  node* left;
  node* right;
 
node(int val){
  data=val;
  left=right=NULL;
  }
};

deque<int> dq;
void inorder(node *root){
 if(root==NULL)
   return;
   
 inorder(root->left);

 dq.push_back(root->data);
 inorder(root->right);
  cout<< root->data<<" ";
}
 
node* insert(node* root, int val){
node *nn=new node(val);
  if(root==NULL){
   return nn;
    }
  if(root->data>val)
     root->left=insert(root->left,val);
  else
    root->right=insert(root->right, val);
  return root;

}
int great(int l,int r){
if(l>r)
 return l;
else
 return r;
 }

int height(node *root){
  if(root==NULL)
    return -1;
  return great(height(root->left), height(root->right))+1;
}

int maximum(node *root){
  if(root->right==NULL)
    return root->data;
    return maximum(root->right);
 }

int minimum(node *root){
  if(root->left==NULL)
    return root->data;
  return minimum(root->left);
}

int ite_maximum(node *root){
  if(root==NULL)
    return -1;
   while(root->right!=0){
      root=root->right;
      }
      return root->data;
      }
      
 void level_order(node * root){
 if(root==NULL)
   return;
   queue<node* > q;
    q.push(root);
 
    while(!q.empty()){
    
    node* top=q.front();
       cout<<top->data<<" ";
       q.pop();
       if(top->left)
         q.push(top->left);
       if(top->right)
         q.push(top->right);
       }
	    
 
 }
 
 node* pre(node* root){
   node* temp=root;
   while(temp->left!=NULL)
     temp=temp->left;
   return temp;
   }
 void swap(int *a, int *b){
  int t=*a;
     *a=*b;
     *b=t;
   }
 node* remove(node* root, int key){
   if(root==NULL)
      return NULL;
   if(key < root->data)
      root->left=remove(root->left, key);
   else if(key > root->data)
     root->right=remove(root->right,key);
   else{
     if(root->left==NULL && root->right==NULL)
       return NULL;
     else if(root->left==NULL && root->right!=NULL)
       return root->right;
     else if(root->right==NULL && root->left!=NULL)
       return root->left;
     else{
      node* prec= pre(root->right);
      swap(prec, root);
      root->right=remove(root->right, prec->data);
      }
 }  
 return root;   
 }
 
int main(){
  node *root=NULL;
  root= insert(root, 10);
  root= insert(root, 5);
  root= insert(root, 20);
  root= insert(root, 4);
  root= insert(root, 6);
  root= insert(root, 1);
  root= insert(root, 2);
  root= insert(root, 11);
  root= insert(root, 25);
  inorder(root);
  cout<<endl;
  int ele;
  cout<<"enter element to remove: ";
  cin>>ele;
  root=remove(root,ele);
   cout<<endl;
  inorder(root);
  cout<<endl;
  cout<<" height of the tree: "<< height(root)<<endl;
  cout<<endl;
//  cout<<" maximum element of the tree: "<< maximim(root)<<endl;
  cout<< dq.back()<<" "<<dq.front();
  cout<<endl;
  cout<<"maximum: "<<maximum(root)<<"  minimum: "<<minimum(root);
   cout<<endl;
  cout<<"maximum: "<<ite_maximum(root);//<<"  minimum: "<<minimum(root);
  cout<<"\nlevel order: \n";
  level_order(root);
  return 0;
}
