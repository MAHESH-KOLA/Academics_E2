#include<bits/stdc++.h>
using namespace std;
struct node{
 int val;
 int pow;
 node* next;
 node(int v,int p){
  val=v;
  pow=p;
  next=NULL;
}
};
void display(node* head1){
  while(head1!=NULL){
   cout<< head1->val<<"  "<<head1->pow;
   cout<<endl;
   head1=head1->next;
   }
   cout<<endl<<endl;
 }
node* poly1(node* head1, int n1){
node* temp;
while(n1--){
 int val,pow;
 cout<< "enter value of "<< n1<<"th power of a polynomial";
 cin>>val>>pow;
 node *nn= new node(val, pow);
 if(head1==NULL){
    head1=nn;
    temp=nn;
    }
 else{
   temp->next=nn;
   temp=nn;
   }
 }
return head1;
}

node* poly2(node* head1, int n1){
node* temp;
while(n1--){
 int val,pow;
 cout<< "enter value of "<< n1<<"th power of a polynomial:  ";
 cin>>val>>pow;
 node *nn= new node(val, pow);
 if(head1==NULL){
    head1=nn;
    temp=nn;
    }
 else{
   temp->next=nn;
   temp=nn;
   }
 }
return head1;
}

node* poly_add(node* head3,node* head1, node* head2){
int val,pow;
node* temp;
  while(head1){
     val=head1->val+head2->val;
     pow=head1->pow;
     node *nn= new node(val, pow);
     if(head3==NULL){
        head3=nn;
        temp=nn;
        }
     else{
     temp->next=nn;
     temp=nn;
     }
     head1=head1->next;
     head2=head2->next;
     }
    return head3;
}

int main(){ 
node* head1=NULL;
node* head2=NULL;
int n1;
cout<<"enter degree of first polynomial: ";
cin>>n1;
n1=n1+1;
head1=poly1(head1,n1);

int n2;
cout<<"enter degree of first polynomial: ";
cin>>n2;
n2=n2+1;
head2=poly2(head2,n2);

 
 display(head1);
 display(head2);
 
 node* head3=NULL;
 head3=poly_add(head3,head1,head2);
 cout<<" polynomial after addition: \n";
  display(head3);
 return 0;
 }
 
